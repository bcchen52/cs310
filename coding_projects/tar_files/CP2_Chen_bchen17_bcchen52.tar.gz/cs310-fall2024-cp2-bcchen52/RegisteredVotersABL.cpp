#include "RegisteredVotersABL.h"
#include <stdexcept>

RegisteredVotersABL::RegisteredVotersABL() {
	a_capacity = 0;
	a_size = 0;
}

RegisteredVotersABL::~RegisteredVotersABL() {
	delete[] v;
}

long unsigned int RegisteredVotersABL::size() {
	return a_size;
}

long unsigned int RegisteredVotersABL::capacity() {
	return a_capacity;
}

void RegisteredVotersABL::resize(long unsigned int n) {
	//capacity only changes if it needs to grow to accomodate change in size
	if(n!=a_size){
		if(n>a_size){
			reserve(n);
		}
		Voter* temp;
		temp = new Voter[a_capacity];

		if(n>a_size){
			//if n > a_size, we fill increase with empty voter until n
			//reserve(n);
			for(long unsigned int i = 0; i < a_size; i++){
				//cout << i << endl;
				temp[i] = v[i];
			}
			for(long unsigned int i = a_size; i < n; i++){
				//cout << i << endl;
				Voter voter;
				temp[i] = voter;
			}
		} else if (n<a_size){
			for(long unsigned int i=0;i<n;i++){
				temp[i] = v[i];
			}
		}

		delete[] v;
		v = temp;
		a_size = n;
	}
}

bool RegisteredVotersABL::empty() {
	return v==NULL;
}

Voter& RegisteredVotersABL::at(long unsigned int pos) {
	//if invalid pos, throw exception
	if(pos>=a_size){
		throw std::out_of_range ("Out of range");
	}
	return (this->v[pos]);
}

Voter &RegisteredVotersABL::front() {
	return v[0];
}

Voter &RegisteredVotersABL::back() {
	return v[a_size-1];
}

void RegisteredVotersABL::reserve(long unsigned int new_cap) {
	//add capacity
	if (new_cap>a_capacity){
		Voter* temp;
		temp = new Voter[new_cap];
		for(long unsigned int i=0;i<a_size;i++){
			temp[i] = v[i];
		}
		delete[] v;
		v = temp;
		a_capacity = new_cap;
	}
}

void RegisteredVotersABL::shrink_to_fit() {
	//decrease capacity
	if (a_size<a_capacity){
		Voter* temp;
		temp = new Voter[a_size];
		for(long unsigned int i=0;i<a_size;i++){
			temp[i] = v[i];
		}
		delete[] v;
		v = temp;
		a_capacity = a_size;
	}
}

void RegisteredVotersABL::clear() {
	//remove all elements, but keep the capacity, i.e. create new array of same capacity w size 0
	delete[] v;
	v = new Voter[a_capacity];
	a_size = 0;
}

void RegisteredVotersABL::pop_back() {
	//create new array with different size
	//but do we really need to change the array if we change size so that the 
	//popped_back element cannot be accessed?
	if (a_size>0){
		Voter* temp;
		temp = new Voter[a_capacity];
		for(long unsigned int i=0;i<a_size-1;i++){
			temp[i] = v[i];
		}
		delete[] v;
		v = temp;
		a_size --;
	}//else do nothing
}

Voter &RegisteredVotersABL::operator[](unsigned int i) {
	if (i >= (unsigned int)a_size){
		Voter* v = new Voter();
		return *v;
	}
	return v[i];
}

void RegisteredVotersABL::push_back(Voter &new_voter) {
	//if there won't be enought capacity, double it 
	if(a_size == a_capacity){
		if(a_capacity>0){
			a_capacity = 2*a_capacity;
		} else {
			a_capacity = 1;
		}
		Voter* temp;
		temp = new Voter[a_capacity];
		for(long unsigned int i=0;i<a_size;i++){
			temp[i] = v[i];
		}
		delete[] v;
		v = temp;
	} 
	v[a_size] = new_voter; 
	a_size ++;
}