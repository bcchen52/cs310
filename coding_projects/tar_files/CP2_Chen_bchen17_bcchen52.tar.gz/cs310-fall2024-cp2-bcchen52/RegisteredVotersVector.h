#ifndef _H_RegisteredVotersVector_
#define _H_RegisteredVotersVector_

#include "Voter.h"
#include<vector>
#include "RegisteredVotersBase.h"

class RegisteredVotersVector : virtual public RegisteredVotersBase {
	private: 
		vector<Voter> v;
	public:
		RegisteredVotersVector(); 
		~RegisteredVotersVector();

		long unsigned int size();
		long unsigned int capacity();
		void resize(long unsigned int n);
		bool empty();

		//implemented
		Voter& at(long unsigned int pos);
		Voter& front();
		Voter& back();
		void reserve(long unsigned int new_cap);
		void shrink_to_fit();
		void clear();
		void pop_back();

		virtual Voter &operator[](unsigned int); 
		virtual void push_back(Voter &); 
};

#endif

