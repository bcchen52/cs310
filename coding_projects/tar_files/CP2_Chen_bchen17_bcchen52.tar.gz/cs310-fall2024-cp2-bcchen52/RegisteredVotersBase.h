#ifndef _H_RegisteredVotersBase_
#define _H_RegisteredVotersBase_

#include "Voter.h"

class RegisteredVotersBase {
	private: 
		// none
	public: 
		//virtual RegisteredVotersBase() = 0;
		~RegisteredVotersBase() {};

		virtual long unsigned int size() = 0;
		virtual long unsigned int capacity() = 0;
		virtual void resize(long unsigned int n) = 0;
		virtual bool empty() = 0;

		//added
		virtual Voter& at(long unsigned int pos) = 0;
		virtual Voter& front() = 0;
		virtual Voter& back() = 0;
		virtual void reserve(long unsigned int new_cap) = 0;
		virtual void shrink_to_fit() = 0;
		virtual void clear() = 0;
		virtual void pop_back() = 0;


		virtual Voter &operator[](unsigned int) = 0; 
		virtual void push_back(Voter &) = 0; 
};

#endif

