#include "RegisteredVotersVector.h"

RegisteredVotersVector::RegisteredVotersVector() {
}

RegisteredVotersVector::~RegisteredVotersVector() {
}

long unsigned int RegisteredVotersVector::size() {
	return v.size();
}

long unsigned int RegisteredVotersVector::capacity() {
	return v.capacity();
}

void RegisteredVotersVector::resize(long unsigned int n) {
	v.resize(n);
}

bool RegisteredVotersVector::empty() {
	return v.empty();
}

Voter& RegisteredVotersVector::at(long unsigned int pos) {
	return v.at(pos);
}

Voter& RegisteredVotersVector::front() {
	return v.front();
}

Voter& RegisteredVotersVector::back() {
	return v.back();
}

void RegisteredVotersVector::reserve(long unsigned int new_cap) {
	v.reserve(new_cap);
}

void RegisteredVotersVector::shrink_to_fit() {
	v.shrink_to_fit();
}

void RegisteredVotersVector::clear() {
	v.clear();
}

void RegisteredVotersVector::pop_back() {
	v.pop_back();
}

Voter &RegisteredVotersVector::operator[](unsigned int i) {
	return v[i];
}

void RegisteredVotersVector::push_back(Voter &new_voter) {
	return v.push_back(new_voter);
}
