#ifndef _H_RegisteredVotersABL_
#define _H_RegisteredVotersABL_

#include "Voter.h"
#include "RegisteredVotersBase.h"

class RegisteredVotersABL : virtual public RegisteredVotersBase {
	private: 
		Voter* v;
		long unsigned int a_size;
		long unsigned int a_capacity;

	public:
		RegisteredVotersABL(); 
		~RegisteredVotersABL();

		long unsigned int size();
		long unsigned int capacity();
		void resize(long unsigned int n);
		bool empty();

		Voter& at(long unsigned int pos);
		Voter& front();
		Voter& back();
		void reserve(long unsigned int new_cap);
		void shrink_to_fit();
		void clear();
		void pop_back();

		virtual Voter &operator[](unsigned int); 
		virtual void push_back(Voter &); 
};

#endif