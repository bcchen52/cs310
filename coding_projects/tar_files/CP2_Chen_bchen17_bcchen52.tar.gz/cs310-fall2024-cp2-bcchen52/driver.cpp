#include <iostream>
#include <stdlib.h>
#include <cassert>
using namespace std;

#include "Voter.h"
#include "RegisteredVotersVector.h"
#include "RegisteredVotersABL.h"

bool empty_test(RegisteredVotersBase &rv, vector<Voter> &v){
   if (rv.empty() != v.empty()) {
	   cout << "Fail: Size mismatch: rv.size(): " << rv.size() << " v.size(): " << 
		   v.size() << endl;
	   return false;
   }
   else 
	   cout << "Pass: Initial empty test" << endl;
   return true;
}

bool initial_size_test(RegisteredVotersBase &rv, vector<Voter> &v) {
   if (rv.size() != v.size()) {
	   cout << "Fail: Size mismatch: rv.size(): " << rv.size() << " v.size(): " << 
		   v.size() << endl;
	   return false;
   }
   else 
	   cout << "Pass: Initial size test. Size is:" << rv.size() << endl;

   if (rv.capacity() != v.capacity()) {
	   cout << "Fail: Capacity mismatch: rv.capacity(): " << rv.capacity() << 
		   " v.capacity(): " << v.capacity() << endl;
	   return false;
   }
   else 
	   cout << "Pass: Initial capacity test. Capacity is: " << rv.capacity() << endl;
   return true;
}

bool resize_test(int n, RegisteredVotersBase &rv, vector<Voter> &v) {
   rv.resize(n);
   v.resize(n);
   if ((rv.capacity() != v.capacity()) || (rv.size() != v.size())) { 
	cout << "Fail: resize to " << n << " test." << endl;
	return false;
   }
   cout << "Pass: resize to " << n << " test. Size is: " << rv.size() << " Capacity is: " << rv.capacity() << endl;
   return true;
}

bool push_back_test(Voter &voter, RegisteredVotersBase &rv, vector<Voter> &v){
   rv.push_back(voter);
   v.push_back(voter);
   if ((rv.size() != v.size() || rv.capacity() != v.capacity())) { 
	cout << "Fail: push_back test." << endl;
	return false;
   }
   cout << "Pass: push_back test. Size:" << rv.size() << " Capacity: " << rv.capacity() << endl;
   cout << "   The last element in rv is:" << endl << "     " ;
   rv.back().show();
   cout << "   The last element in v is:" << endl << "     " ;
   v.back().show();
   cout << endl;
   return true;
}

bool shrink_to_fit_test(RegisteredVotersBase &rv, vector<Voter> &v){
   rv.shrink_to_fit();
   v.shrink_to_fit();
   if ((rv.size() != v.size())) { 
	cout << "Fail: shrink_to_fit test." << endl;
	return false;
   }
   cout << "Pass: shrink_to_fit test. Size:" << rv.size() << " Capacity: " << rv.capacity() << endl;
   return true;
}

bool reserve_test(int n, RegisteredVotersBase &rv, vector<Voter> &v) {
   rv.reserve(n);
   v.reserve(n);
   if ((rv.capacity() != v.capacity()) || (rv.size() != v.size())) { 
	cout << "Fail: Reserve " << n << " test." << endl;
	return false;
   }
   cout << "Pass: Reserve " << n << " test. Capacity is: " << rv.capacity() << endl;
   return true;
}

bool pop_back_test(RegisteredVotersBase &rv, vector<Voter> &v){
   rv.pop_back();
   v.pop_back();
   if ((rv.capacity() != v.capacity()) || (rv.size() != v.size())) { 
	cout << "Fail: pop_back test." << endl;
	return false;
   }
   cout << "Pass: pop_back test. Size:" << rv.size() << " Capacity: " << rv.capacity() << endl;
   return true;
}

bool at_test(int n, RegisteredVotersBase &rv, vector<Voter> &v){
   cout << "Pass: at test" << endl;
   cout << "   at(" << n << "): " << endl << "  ";
   rv.at(n).show();
   cout << "   at(" << n << "): " << endl << "  ";
   v.at(n).show();
   return true;
}

int main() {
   Voter one;
   Voter two("Brian", "Chen", 12);
   RegisteredVotersABL rva;
   vector<Voter> cppv;
   vector<Voter> cppv2;
   RegisteredVotersVector rvv;
   

   cout << "For Vector:" << endl;
   assert(empty_test(rvv, cppv));
   assert(initial_size_test(rvv, cppv));
   assert(push_back_test(two, rvv, cppv));
   assert((pop_back_test(rvv, cppv)));
   assert(reserve_test(10, rvv, cppv));
   assert(shrink_to_fit_test(rvv, cppv));
   assert(resize_test(10, rvv, cppv));
   assert(push_back_test(one, rvv, cppv));
   assert(push_back_test(two, rvv, cppv));
   assert(push_back_test(two, rvv, cppv));
   assert(shrink_to_fit_test(rvv, cppv));
   assert(reserve_test(20, rvv, cppv));
   assert(at_test(12, rvv, cppv));
   

   cout << endl << "For ABL:" << endl;
   assert(empty_test(rva, cppv2));
   assert(initial_size_test(rva, cppv2));
   assert(push_back_test(two, rva, cppv2));
   assert((pop_back_test(rva, cppv2)));
   assert(reserve_test(10, rva, cppv2));
   assert(shrink_to_fit_test(rva, cppv2));
   assert(resize_test(10, rva, cppv2));
   assert(push_back_test(one, rva, cppv2));
   assert(push_back_test(two, rva, cppv2));
   assert(push_back_test(two, rva, cppv2));
   assert(shrink_to_fit_test(rva, cppv2));
   assert(reserve_test(20, rva, cppv2));
   assert(at_test(12, rva, cppv2));
   assert(shrink_to_fit_test(rva, cppv2));
   for(int i=0;i<100;i++){
      assert(push_back_test(two, rva, cppv2));
   }  

}
