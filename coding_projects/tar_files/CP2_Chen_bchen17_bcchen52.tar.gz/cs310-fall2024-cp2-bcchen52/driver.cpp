#include <iostream>
#include <stdlib.h>
#include <cassert>
using namespace std;

#include "Voter.h"
#include "RegisteredVotersVector.h"
#include "RegisteredVotersABL.h"

bool initial_size_test(RegisteredVotersBase &rv, vector<Voter> &v) {
    if (rv.size() != v.size()) {
        cout << "Fail: Size mismatch: rv.size(): " << rv.size() << " v.size(): " << 
            v.size() << endl;
        return false;
    }
    else 
        cout << "Pass: Initial size test" << endl;

    // rv.capacity()
    if (rv.capacity() != v.capacity() && rv.capacity() != 1) {
        cout << "Fail: Capacity mismatch: rv.capacity(): " << rv.capacity() << 
            " v.capacity(): " << v.capacity() << endl;
        return false;
    }
    else 
        cout << "Pass: Initial capacity test." << endl;
    return true;
}

bool resize_test(int n, RegisteredVotersBase &rv, vector<Voter> &v ) {
    rv.resize(n);
    v.resize(n);
    if ((rv.capacity() != v.capacity()) || (rv.size() != v.size())) { 
        cout << "Fail: resize to " << n << " test." << endl;
        return false;
    }
    cout << "Pass: resize to " << n << " test." << endl;
    return true;
}


bool grow_test( RegisteredVotersBase &rvv ){
    // RegisteredVotersVector [4 pts]: 
    //    This class can be used to grow a container to include 100+ voters. 
    //    The behavior correctly mirrors the behavior when the program uses a C++ vector directly.

    unsigned long int n = rvv.size() + 101;
    for (unsigned long int i = 0; i < 101; i++){
        Voter vt;
        rvv.push_back( vt );
    }

    if ( rvv.size() != n ) { 
        cout << "Fail: grow RegisteredVotersVector to " << n << " test." << endl; 
        return false;
    }
    cout << "Pass: grow RegisteredVotersVector to " << n << " test." << endl;
    return true;
}


/* RegisteredVotersBase - size functions [12 pts]: 
   [8 pts] empty(), size(), reserve(), capacity(), and shrink_to_fit(), and resize()
   all mirror the behavior when called directly on a C++ vector, returning the same
   values. These can be tested without storing any actual voter objects.
   */

bool empty_test( RegisteredVotersBase &rva ){
    if (!rva.empty()) {
        cout << "Fail: RegisteredVotersBase empty test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersBaseE empty test." << endl;
    return true;
}

bool size_test( RegisteredVotersBase &rva, unsigned long int n ){
    if (rva.size() != n) {
        cout << "Fail: RegisteredVotersBase size = " << n << " test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersBase size = " << n << " test." << endl; 
    return true;
}

bool clear_test(RegisteredVotersBase& rvv) {
    rvv.clear();
    if (!size_test(rvv, 0) || !empty_test(rvv)) {
        cout << "Fail: RegisteredVotersBase clear test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersBase clear test." << endl;
    return true;
}


bool reserve_test( RegisteredVotersBase &rva, vector<Voter>& rv, unsigned long int n ){
    rva.reserve(n);
    rv.reserve(n);
    if (rva.capacity() != rv.capacity()) {
        cout << "Fail: RegisteredVotersBase reserve(" << n << ") test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersBase reserve(" << n << ") test." << endl; 
    return true;
}

bool shrink_to_fit_test(RegisteredVotersBase &rva, vector<Voter>& rv){
    rva.shrink_to_fit();
    rv.shrink_to_fit();
    if (rva.size() != rv.size() || rva.capacity() != rv.capacity()) {
        cout << "Fail: RegisteredVotersBase shrink_to_fit test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersBase shrink_to_fit test." << endl; 
    return true;

}

// RegisteredVotersBase - push_back(), pop_back(), and at() [20 pts]:

bool push_back_test(RegisteredVotersBase &rv, vector<Voter> &v){
    for (unsigned int i = 0; i < 101; ++i) {
        if (rv.size() != v.size() || rv.capacity() != v.capacity()) {
            cout << "Fail: RegisteredVotersBase push_back() test " << i << "." << endl; 
            return false;
        }
        Voter v1 = Voter{
            string{static_cast<char>('A' + i)},
            string{static_cast<char>('A' + i + 1)},
            i
        };
        rv.push_back(v1);
        v.push_back(v1);
    }
    cout << "Pass: RegisteredVotersBase push_back() test " << rv.size() << "." << endl; 
    return true;
}

bool pop_back_test(RegisteredVotersBase &rv, vector<Voter> &v){
    if (rv.size() != v.size()) {
        cout << "Fail: RegisteredVotersBase pop_back() test 0." << endl; 
        return false;
    }
    for (int i = 0; i < 101; ++i) {
        rv.pop_back();
        v.pop_back();
        if (rv.size() != v.size()) {
            cout << "Fail: RegisteredVotersBase pop_back() test " << i << "." << endl; 
            return false;
        }
    }
    cout << "Pass: RegisteredVotersBase pop_back() test 0." << endl; 
    return true;
}

bool at_test(RegisteredVotersBase &rv, vector<Voter> &v){
    if (rv.at(0) != v.at(0)) {
        cout << "Fail: RegisteredVotersVector at 0 test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersVector at 0 test." << endl; 
    if (rv.at(1) != v.at(1)) {
        cout << "Fail: RegisteredVotersVector at 1 test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersVector at 1 test." << endl; 
    if (rv.at(15) != v.at(15)) {
        cout << "Fail: RegisteredVotersVector at 15 test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersVector at 15 test." << endl; 
    if (rv.at(rv.size() - 1) != v.at(rv.size() - 1)) {
        cout << "Fail: RegisteredVotersVector at " << (rv.size() - 1) << " test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersVector at " << (rv.size() - 1) << " test." << endl; 
    if (rv.at(1) == v.at(0)) {
        cout << "Fail: RegisteredVotersVector operator[] comparison test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersVector operator[] comparison test." << endl; 

    if (rv[0] != v[0]) {
        cout << "Fail: RegisteredVotersVector operator[] 0 test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersVector operator[] 0 test." << endl; 
    if (rv[1] != v[1]) {
        cout << "Fail: RegisteredVotersVector operator[] 1 test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersVector operator[] 1 test." << endl; 
    if (rv[15] != v[15]) {
        cout << "Fail: RegisteredVotersVector operator[] 15 test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersVector operator[] 15 test." << endl; 
    if (rv[rv.size() - 1] != v[rv.size() - 1]) {
        cout << "Fail: RegisteredVotersVector operator[] " << (rv.size() - 1) << " test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersVector operator[] " << (rv.size() - 1) << " test." << endl; 
    if (rv[1] == v[0]) {
        cout << "Fail: RegisteredVotersVector operator[] comparison test." << endl; 
        return false;
    }
    cout << "Pass: RegisteredVotersVector operator[] comparison test." << endl; 
    return true;
}



int main() {
    RegisteredVotersVector rvv;
    vector<Voter> cppv;

    assert(initial_size_test(rvv, cppv));
    assert(resize_test(10, rvv, cppv));

    RegisteredVotersVector rvv_g;
    assert(grow_test(rvv_g));

    assert(grow_test(rvv));
    for (unsigned int i = cppv.size(); i < rvv.size(); ++i) {
        cppv.push_back({});
    }

    assert(reserve_test(rvv, cppv, 1234));

    assert(clear_test(rvv));
    cppv.clear();

    assert(empty_test(rvv));

    assert(shrink_to_fit_test(rvv, cppv));
    assert(push_back_test(rvv, cppv));
    assert(pop_back_test(rvv, cppv));
    assert(push_back_test(rvv, cppv));
    assert(push_back_test(rvv, cppv));
    assert(at_test(rvv, cppv));

    cout << "All RegisteredVotersVector tests passed!" << endl;

    RegisteredVotersABL rva;
    vector<Voter> cppv2;

    assert(initial_size_test(rva, cppv2));
    assert(resize_test(10, rva, cppv2));

    RegisteredVotersVector rva_g;
    assert(grow_test(rva_g));

    assert(grow_test(rva));
    for (unsigned int i = cppv2.size(); i < rva.size(); ++i) {
        cppv2.push_back({});
    }

    assert(reserve_test(rva, cppv2, 1234));

    assert(clear_test(rva));
    cppv2.clear();

    assert(empty_test(rva));

    assert(shrink_to_fit_test(rva, cppv2));
    assert(push_back_test(rva, cppv2));
    assert(pop_back_test(rva, cppv2));
    assert(push_back_test(rva, cppv2));
    assert(push_back_test(rva, cppv2));
    assert(at_test(rva, cppv2));
    cout << "All tests passed!" << endl;
}
