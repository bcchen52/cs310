#include <iostream>
#include <stdlib.h>
using namespace std;

#include "Voter.h"
#include "RegisteredVotersVector.h"
#include "RegisteredVotersABL.h"

int main() {
   Voter one("Brian", "One", 12);
   Voter two("Brian", "Two", 12);
   Voter three("Brian", "Three", 12);
   Voter four("Brian", "Four", 12);
   Voter five("Brian", "Five", 12);

   //initialize
   RegisteredVotersVector rvv;
   RegisteredVotersABL rva;

   //sizes of both
   cout << "-----" << "Sizes of both initially" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Size of rvv: " << rvv.size() << endl;
   cout << "Capacity of rvv: " << rvv.capacity() << endl;   
   cout << "RVA" << "-----" << endl;
   cout << "Size of rva: " << rva.size() << endl;
   cout << "Capacity of rva: " << rva.capacity() << endl << endl;

   //add one voter
   rva.push_back(one);
   rvv.push_back(one);
   cout << "-----" << "Sizes of both after adding one" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Size of rvv: " << rvv.size() << endl;
   cout << "Capacity of rvv: " << rvv.capacity() << endl;   
   cout << "RVA" << "-----" << endl;
   cout << "Size of rva: " << rva.size() << endl;
   cout << "Capacity of rva: " << rva.capacity() << endl << endl;

   rva.push_back(two);
   rva.push_back(three);
   rvv.push_back(two);
   rvv.push_back(three);
   cout << "-----" << "Sizes of both after adding two more, for three total" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Size of rvv: " << rvv.size() << endl;
   cout << "Capacity of rvv: " << rvv.capacity() << endl;   
   cout << "RVA" << "-----" << endl;
   cout << "Size of rva: " << rva.size() << endl;
   cout << "Capacity of rva: " << rva.capacity() << endl << endl;

   rva.reserve(5);
   rvv.reserve(5);
   cout << "-----" << "Sizes of both after calling reserve(5)" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Size of rvv: " << rvv.size() << endl;
   cout << "Capacity of rvv: " << rvv.capacity() << endl;   
   cout << "RVA" << "-----" << endl;
   cout << "Size of rva: " << rva.size() << endl;
   cout << "Capacity of rva: " << rva.capacity() << endl << endl;

   rva.shrink_to_fit();
   rvv.shrink_to_fit();
   cout << "-----" << "Sizes of both after calling shrink_to_fit()" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Size of rvv: " << rvv.size() << endl;
   cout << "Capacity of rvv: " << rvv.capacity() << endl;   
   cout << "RVA" << "-----" << endl;
   cout << "Size of rva: " << rva.size() << endl;
   cout << "Capacity of rva: " << rva.capacity() << endl << endl;

   rva.resize(10);
   rvv.resize(10);
   cout << "-----" << "Sizes of both after calling resize(10), s.t. the capacity changes" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Size of rvv: " << rvv.size() << endl;
   cout << "Capacity of rvv: " << rvv.capacity() << endl;   
   cout << "RVA" << "-----" << endl;
   cout << "Size of rva: " << rva.size() << endl;
   cout << "Capacity of rva: " << rva.capacity() << endl << endl;
   //cout << rva.size() << endl;
   //cout << rva.capacity() << endl;

   cout << "-----" << "Indexing with [] in range" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Voter at [2]: ";
   rvv[2].show();
   cout << "RVA" << "-----" << endl;
   cout << "Voter at [2]: ";
   rva[2].show();
   cout << endl;

   rva.resize(2);
   rvv.resize(2);
   cout << "-----" << "Sizes of both after calling resize(2), less, than capacity" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Size of rvv: " << rvv.size() << endl;
   cout << "Capacity of rvv: " << rvv.capacity() << endl;   
   cout << "RVA" << "-----" << endl;
   cout << "Size of rva: " << rva.size() << endl;
   cout << "Capacity of rva: " << rva.capacity() << endl << endl;

   cout << "-----" << "Indexing with [] out of range" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Voter at [2]: ";
   rvv[2].show();
   cout << "RVA" << "-----" << endl;
   cout << "Voter at [2]: ";
   rva[2].show();
   cout << endl;

   cout << "-----" << "Indexing with .at()" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Voter .at(1): ";
   rvv.at(1).show();
   cout << "RVA" << "-----" << endl;
   cout << "Voter .at(1): ";
   rva.at(1).show();
   cout << endl;

   cout << "-----" << "Using .back()" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "rvv.back().show(): ";
   rvv.back().show();
   cout << "RVA" << "-----" << endl;
   cout << "rva.back().show(): ";
   rva.back().show();
   cout << endl;

   rvv.pop_back();
   rva.pop_back();
   cout << "-----" << "Sizes of both after calling pop_back" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Size of rvv: " << rvv.size() << endl;
   cout << "Capacity of rvv: " << rvv.capacity() << endl;   
   cout << "RVA" << "-----" << endl;
   cout << "Size of rva: " << rva.size() << endl;
   cout << "Capacity of rva: " << rva.capacity() << endl << endl;

   cout << "-----" << "Using .back()" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "rvv.back().show(): ";
   rvv.back().show();
   cout << "RVA" << "-----" << endl;
   cout << "rva.back().show(): ";
   rva.back().show();
   cout << endl;

   rva.resize(4);
   rvv.resize(4);
   cout << "-----" << "Sizes of both after calling resize(4), s.t. the capacity does not change" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "Size of rvv: " << rvv.size() << endl;
   cout << "Capacity of rvv: " << rvv.capacity() << endl;   
   cout << "RVA" << "-----" << endl;
   cout << "Size of rva: " << rva.size() << endl;
   cout << "Capacity of rva: " << rva.capacity() << endl << endl;

   cout << "-----" << "Using .back()" << "-----"<< endl;
   cout << "RVV" << "-----" << endl;
   cout << "rvv.back().show(): ";
   rvv.back().show();
   cout << "RVA" << "-----" << endl;
   cout << "rva.back().show(): ";
   rva.back().show();
   cout << endl;

   
}

