#include <iostream>
#include <stdlib.h>
#include "Voter.h"
using namespace std;
#ifndef REGISTEREDVOTERS_H
#define REGISTEREDVOTERS_H

class RegisteredVoters {
   public:
      RegisteredVoters(Voter* new_voter);

      RegisteredVoters();
      
      void show();

   private:
      Voter* voter;
      unsigned int size = 0;
};

#endif