#include "RegisteredVoters.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

RegisteredVoters::RegisteredVoters(Voter* new_voter) {
   voter = new_voter;
   size = 1;
}

RegisteredVoters::RegisteredVoters() {
   size = 0;
}

void RegisteredVoters::show() {
   cout << "There are " << size << " voter(s). They are..." << endl;
   voter->show();
}