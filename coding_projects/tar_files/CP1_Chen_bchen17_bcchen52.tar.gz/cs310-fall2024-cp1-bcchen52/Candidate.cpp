#include "Candidate.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

Candidate::Candidate(){
    name = "";
    age = 0;
    party = "";
}

Candidate::Candidate(string candidate_name, unsigned int candidate_age, string candidate_party){
    name = candidate_name;
	age = candidate_age;
	party = candidate_party;
}

void Candidate::show(){
    cout << name << " [" << party << "] Age " << age << endl;
}