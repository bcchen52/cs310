# cs310-Fall2024-cp1

Full Name: Brian Chen 

GitHub ID: bcchen52

Binghamton CS userid: bchen17

Discord name: run3father

Please type or copy the CS 310 honesty statement here:

I have worked on this project individually, and have not given or received too much help. In particular, I have not gained access to any other students' repositories, files, or code, nor have I given any other students access to mine. I have not used generative AI, including but not limited to chatGPT, unless explicitly authorized for this assignment. I understand that my code will be run through a very effective similarity checker, and that academic honesty violations are taken seriously.


With respect to the honesty statement, if you have any doubts whatsoever about
whether you have completed the assignment appropriately, please describe briefly here:




