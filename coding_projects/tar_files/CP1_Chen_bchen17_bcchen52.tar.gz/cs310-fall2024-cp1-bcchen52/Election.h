#include <iostream>
#include <stdlib.h>
#include "Candidate.h"
#include "RegisteredVoters.h"
using namespace std;

class Election {
    public:
        Election(Candidate* one, Candidate* two, RegisteredVoters* v);

        void show();

    private:
        Candidate* candidate_one;
        Candidate* candidate_two;
        RegisteredVoters* voters;
};