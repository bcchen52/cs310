#include <iostream>
#include <stdlib.h>
#ifndef VOTER_H
#define VOTER_H

using namespace std;

class Voter {
   public:
      Voter();
      Voter(string firstname, string lastname, unsigned int voterage);
      void show();

   private:
      string first = "";
      string last = "";
      unsigned int age = 0;
};

#endif