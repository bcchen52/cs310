#include "Voter.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

Voter::Voter(string firstname, string lastname, unsigned int voterage) {
   first = firstname;
   last = lastname;
   age = voterage;
}

Voter::Voter() {
   first = "";
   last = "";
   age = 0;
}

void Voter::show() {
   cout << last << ", " << first << ": " << age << endl;
}