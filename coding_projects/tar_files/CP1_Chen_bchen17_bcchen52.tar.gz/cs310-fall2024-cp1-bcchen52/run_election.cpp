#include "Voter.h"
#include "RegisteredVoters.h"
#include "Candidate.h"
#include "Election.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

int main(int argc, char *argv[]) {
   cout << "Empty voter object:" << endl;
   Voter one;
   one.show();
   cout << endl;

   cout << "Voter object:" << endl;
   Voter two("Silly", "Sally", 17);
   two.show();
   cout << endl;

   cout << "Voter object w/ pointer:" << endl;
   Voter *three = new Voter("Brian", "Chen", 21);
   three->show();
   cout << endl;

   cout << "RegisterVoters pointer w Voter object:" << endl;
   RegisteredVoters *registered = new RegisteredVoters(three);
   registered->show();
   cout << endl;
   
   Candidate* c1 = new Candidate("Bernie", 100, "Dem");
   Candidate* c2 = new Candidate("Trump", 120, "Rep");

   Election* election = new Election(c1, c2, registered);
   election->show();

   delete(three);
   delete(registered);
   delete(c1);
   delete(c2);
   delete(election);
}