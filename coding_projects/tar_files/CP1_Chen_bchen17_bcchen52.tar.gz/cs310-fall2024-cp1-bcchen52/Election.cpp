#include "Election.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

Election::Election(Candidate* one, Candidate* two, RegisteredVoters* v){
    candidate_one = one;
    candidate_two = two;
    voters = v;
}

void Election::show(){
    cout << "Candidate one: ";
    candidate_one->show();
    cout << endl;
    cout << "Candidate two: ";
    candidate_two->show();
    cout << endl;
    cout << "Register voters: ";
    voters->show();
    cout << endl;
}