#include <iostream>
#include <stdlib.h>
using namespace std;
#ifndef CANDIDATE_H
#define CANDIDATE_H

class Candidate {
    public:
      Candidate(string candidate_name, unsigned int candidate_age, string candidate_party);

      Candidate();

      void show();

   private:
      string name = "";
      unsigned int age = 0;
      string party = "";
};
#endif