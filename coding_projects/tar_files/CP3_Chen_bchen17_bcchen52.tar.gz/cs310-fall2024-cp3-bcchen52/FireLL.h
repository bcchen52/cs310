#ifndef FireLL_H
#define FireLL_H

#include <iostream>
#include <stdlib.h>
using namespace std;

template<typename T>
class FireLL{
    public:
        FireLL();
        ~FireLL();
        bool isEmpty();
        bool makeEmpty();
        bool may_contain_dups();
        bool ordered();
        bool add_left(const T& v, bool no_dups);
        bool add_right(const T& v, bool no_dups);
        int sort();
        bool remove_dups();
        FireLL &import(const FireLL &other, bool no_dups, bool maintain_order);
        FireLL &operator+=(const FireLL &other);

        //Rule of Three
       
        FireLL(const FireLL& origObject);
        FireLL& operator=(const FireLL& origObject);

        //iterator
        bool restart();
        bool done();
        T go_to_next();

    private:
        T* counter;
        T* head;
        T* tail;
        bool is_ordered;
        bool dups;
};

#include "FireLL.cpp"

#endif