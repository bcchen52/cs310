#include "Voter.h"

Voter::Voter(string firstname, string lastname, unsigned int voterage) {
	first = firstname;
	last = lastname;
	age = voterage;
	next = nullptr;
	prev = nullptr;
}

Voter::Voter() {
	first = "";
	last = "";
	age = 0;
	next = nullptr;
	prev = nullptr;
}

Voter::Voter(const Voter& origObject){
	first = origObject.first;
	last = origObject.last;
	age = origObject.age;
	next = origObject.next;
	prev = origObject.prev;
}

void Voter::show() {
	cout << last << ", " << first << ": " << age << endl;
}

bool Voter::operator==(const Voter& other) const {
	return (first == other.first) && 
        (last == other.last) && 
        (age == other.age); 
}

bool Voter::operator!=(const Voter& other) const {
    return !(*this == other);
}

bool Voter::operator<(const Voter& other) const {
	if(last != other.last){
		return last < other.last;
	} else {
		if(first != other.first){
			return first < other.first;
		} else {
			if(age != other.age){
				return age < other.age;
			}
		}
	}
	return false;
}

bool Voter::operator>(const Voter& other) const {
	if(last != other.last){
		return last > other.last;
	} else {
		if(first != other.first){
			return first > other.first;
		} else {
			if(age != other.age){
				return age > other.age;
			}
		}
	}
	return false;
}

std::ostream& operator<<(std::ostream& os, const Voter& voter){
	os << voter.last << ", " << voter.first << ", " << voter.age;
	return os;
}

