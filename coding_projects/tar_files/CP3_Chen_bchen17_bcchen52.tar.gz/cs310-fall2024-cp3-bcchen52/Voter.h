#ifndef _H_Voter_
#define _H_Voter_

#include <iostream>
#include <stdlib.h>
using namespace std;

class Voter {
   private:
      string first = "";
      string last = "";
      unsigned int age = 0;

   public:
      Voter* next;
      Voter* prev;
      Voter(string firstname, string lastname, unsigned int voterage);
      Voter();
      Voter(const Voter& origObject);
      void show();
      bool operator==(const Voter& other) const;
      bool operator!=(const Voter& other) const;
      bool operator<(const Voter& other) const;
      bool operator>(const Voter& other) const;
      friend std::ostream& operator<<(std::ostream& os, const Voter& voter);
};

#endif
