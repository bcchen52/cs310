#include "FireLL.h"
#include "Voter.h"

template<typename T>
FireLL<T>::FireLL(){
    head = nullptr;
    tail = nullptr;
    is_ordered = true;
    dups = false;
    counter = nullptr;
}

template<typename T>
bool FireLL<T>::isEmpty(){
    return head == nullptr;
}

template<typename T>
bool FireLL<T>::makeEmpty(){
    if(!isEmpty()){
        T* current = head;
        T* next = nullptr;
        while(current != nullptr){
            next = current->next;
            delete current;
            current = next;
        }
        head = nullptr;
        tail = nullptr;
        return true;
    }
    return false;
}

template<typename T>
bool FireLL<T>::may_contain_dups(){
    //if(head==nullptr || head->next==nullptr){return false;}
    return dups;
}

template<typename T>
bool FireLL<T>::ordered(){
    return is_ordered;
}

template<typename T>
bool FireLL<T>::add_left(const T& j, bool no_dups){
   T* k = new T(j);
    if(head==nullptr){
        head = k;
        tail = k;
        return true;
    } else {
        if(no_dups){
            //no_dups true => dups not allowed
            T* current = head;
            bool match = false;
            while(current!=nullptr){
                if(*current==*k){
                    match = true;
                }
                current = current->next;
            }
            if(!match){
                head->prev = k;
                k->next = head;
                head = k;
                k->prev = nullptr;
                is_ordered = false; 
                return true;
            }
        } else {
            head->prev = k;
            k->next = head;
            head = k;
            k->prev = nullptr;
            is_ordered = false; 
            dups = true;
            return true;
        }
    }
    return false; 
}

template<typename T>
bool FireLL<T>::add_right(const T& j, bool no_dups){
    T* k = new T(j);
    if(head==nullptr){
        head = k;
        tail = k;
        return true;
    } else {
        if(no_dups){
            //no_dups true => dups not allowed
            T* current = head;
            bool match = false;
            while(current!=nullptr){
                if(*current==*k){
                    match = true;
                }
                current = current->next;
            }
            if(!match){
                tail->next = k;
                k->prev = tail;
                tail = k;
                k->next = nullptr;
                is_ordered = false; 
                return true;
            } else {
                delete k;
            }
        } else {
            tail->next = k;
            k->prev = tail;
            tail = k;
            k->next = nullptr;
            is_ordered = false; 
            dups = true;
            return true;
        }
    }
    return false; 
}

template<typename T>
int FireLL<T>::sort(){
    int counter = 0;
    T* current = head;
    T* second = head;
    T* temp = head;
    T* temp2 = nullptr;
    while(current!=nullptr){
        temp = current;
        second = current->next;
        while(second!=nullptr){
            if(*second < *temp){
                temp = second; 
            }
            second = second->next;
        }

        temp2 = current->next;

        if(*temp != *current){
            counter ++;
            //cout << counter << " ";
            T* p1_n = current->next;
            T* p1_p = current->prev;
            T* p2_n = temp->next;
            T* p2_p = temp->prev;
            if(current->next == temp){
                current->next = temp->next; 
                if (current->next != nullptr) {
                    current->next->prev = current; 
                }
                temp->prev = p1_p;
                temp->next = current;
                current->prev = temp; 
                if (p1_p != nullptr) {
                    p1_p->next = temp; 
                } else {
                    head = temp; 
                }
                if (p2_n != nullptr) {
                    p2_n->prev = current; 
                } else {
                    tail = current; 
                }
            } else {
                temp->prev = p1_p;
                temp->next = p1_n;
                current->prev = p2_p;
                current->next = p2_n;

                if (p1_n != nullptr) {
                    p1_n->prev = temp; // Link next node's prev to temp
                }
                if(p1_p!=nullptr){
                    p1_p->next = temp;
                } else {
                    head = temp;
                }

                p2_p->next = current; // Link previous node's next to current
                //p2_p->next=current;
                if(p2_n!=nullptr){
                    p2_n->prev = current;
                } else {
                    tail = current;
                }
            }

            
        } 
        current=temp2;
    }
    is_ordered = true;
    return counter;
}

template<typename T>
bool FireLL<T>::remove_dups(){
    bool changed = false;
    if(is_ordered){
        T* current = head;
        T* second = head;
        while(current!=nullptr){
            second = current->next;
            while(*second == *current){
                changed = true;
                current->next = second->next;
                if(second->next!=nullptr){
                    second->next->prev = current;
                } else {
                    tail = current; 
                }
                delete second; 
                second = current->next;
            }
            current = current->next;
        }
    } else {
        T* current = head;
        T* second = head;
        while(current!=nullptr){
            second = current->next;
            while(second != nullptr){
                if(*second == *current){
                    changed = true;
                    T* second2 = second->next;
                    second->prev->next = second->next;
                    if(second2!=nullptr){
                        second->next->prev = second->prev;
                    } else {
                        tail = second->prev;
                    }
                    delete second; 
                    second = second2;
                } else {
                    second = second->next;
                }
            }
            current = current->next;
        }
    }
    dups = false;
    return changed; 
}

template<typename T>
FireLL<T>& FireLL<T>::import(const FireLL &other, bool no_dups, bool maintain_order){
    if (this == &other) return *this;
    T* current = other.head;
    while(current!=nullptr){
        //T newValue = *current;
        this->add_right(*current, no_dups);
        current = current->next;
    }
    if(maintain_order){
        this->sort();
    }
    return *this;
}

template<typename T>
FireLL<T>& FireLL<T>::operator+=(const FireLL &other){
    return this->import(other, true, true);
}

template<typename T>
FireLL<T>::~FireLL(){
    makeEmpty();
}

template<typename T>
FireLL<T>::FireLL(const FireLL& origObject){
    head = origObject.head;
    tail = origObject.head;
    is_ordered = origObject.is_ordered;
    dups = origObject.dups;
    counter = origObject.counter;
    T* current = origObject.head;
    while(current!=nullptr){
        add_right(*current, !dups);
        current = current->next;
    }
}

template<typename T>
FireLL<T>& FireLL<T>::operator=(const FireLL& origObject){
    if (this == &origObject) {  
        return *this; 
    }
    makeEmpty();

    head = origObject.head;
    tail = origObject.head;
    is_ordered = origObject.is_ordered;
    dups = origObject.dups;
    counter = origObject.counter;
    T* current = origObject.head;
    while(current!=nullptr){
        add_right(*current, !dups);
        current = current->next;
    }
    return *this;
}

template<typename T>
bool FireLL<T>::restart(){
    if(!isEmpty()){
        counter = head;
    }
    return !isEmpty();
}

template<typename T>
bool FireLL<T>::done(){
    return counter == nullptr;
}

template<typename T>
T FireLL<T>::go_to_next(){
    T copy;
    if(counter != nullptr){
        copy = *counter;
        counter = counter->next; 
    }
    return copy;
}