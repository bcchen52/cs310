#include "RegisterVoter.h"

RegisterVoter::RegisterVoter(){
    bst = new BST();
    aVector = new ageVector();
    //ageVector->initalize;
}

bool RegisterVoter::voter(string first, string last, int age){

    //Add to BST, check if it exists
    Voter* v = new Voter(first, last, age);

    if(age<18 || age>118){
        cout << "Voter age should be between 18 and 118" << endl;
        delete v;
        return false;
    }

    if(bst->addVoter(v)){
        v->set_position(ivector.size());
        ivector.push_back(v);
        percolate_up(v);

        aVector->insertV(v);

        cout << "New voter ";
        v->show();
        cout << ", added." << endl;
        return true;
    }

    cout << "Voter ";
    v->show();
    cout << " already exists." << endl;

    delete v;

    return false;
};

void RegisterVoter::voted(string first, string last, int age){
    //voted

    //remove from bst
    Voter* curr = bst->deleteNodeRec(last,first);

    if(curr != nullptr){

        //remove from array
        aVector->removeV(curr);

        Voter *swapped = ivector[ivector.size()-1];
        ivector[curr->get_position()] = swapped;
        swapped->set_position(curr->get_position());
        ivector.pop_back();
        percolate_down(swapped,ivector.size());

        cout << "Voter ";
        curr->show();
        cout << " voted." << endl;

        delete curr;
    } else {
        cout << first << " " << last << ", age " << age << " does not exist or has already voted." << endl;
    }

};

void RegisterVoter::reduce_likelihood(string first, string last, double change){
    //reducing likelihood decreases impact, percolte down
    Voter* curr = bst->search(last, first);

    if(curr != nullptr){
        curr->updateLikelihood(change);
        percolate_up(curr);
        //print message
        cout << "Voting liklihood of ";
        curr->name();
        cout << " decreased by " << change << "%" << endl;
    } else {
        cout << first << " " << last << " does not exist or has already voted.";
    }
};

void RegisterVoter::support(string first, string last, double change){
    //increase support increases likelhood, perolate up
    Voter* curr = bst->search(last, first);

     if(curr != nullptr){ 
        curr->updateStrength(change);
        percolate_up(curr);
        //print message

        cout << "Support from ";
        curr->name();
        cout << " increase by " << change << " strength points." << endl;
    } else {
        cout << first << " " << last << " does not exist or has already voted.";
    }
};

void RegisterVoter::chauffeur(){
    bool chauffeured = false;
    Voter* curr;
    Voter* voting;

    if(ivector.size()>0){
        chauffeured = true;
        voting = ivector[0];

        //delete age vector

        if(ivector.size()>1){
            curr = ivector[ivector.size()-1];
            curr->set_position(0);
            ivector[0] = curr;

            ivector.pop_back();
            //pop off voted

            //percolate down()
            percolate_down(curr, ivector.size());
        } else {
            ivector.pop_back();
        }
    }

    //print voter
    if(chauffeured){
        //remove from array
        aVector->removeV(voting);

        //remove from bst
        //UPDTE THIS
        bst->deleteNode(voting->getLastName(), voting->getFirstName());
        cout << "Driving ";
        voting->show_full();
        cout << endl;
        delete voting;
    } else {
        cout << "No one to drive." << endl;
    }

    //delete voter
};

void RegisterVoter::show_impact(){
    //loop thru vector
    aVector->showImpact();
};

bool RegisterVoter::swap_up(int current_index){
    if(current_index > 0){
        Voter* child = ivector[current_index];
        Voter* parent = ivector[(current_index-1)/2];
        //if swapped and it has a child, return true if it has a child
        //use max and index 
        if(parent->impactCompare(*child)){
            //if parent impact(Compare) child => parent < Child
            //change positions
            child->set_position(parent->get_position());
            parent->set_position(current_index);
            //change in vector
            ivector[child->get_position()] = child;
            ivector[parent->get_position()] = parent;
            return false;
        }
    }
    return true;
}

bool RegisterVoter::swap_down(int current_index, int max){
    int swap_with = 0;
    //change positionsss
    Voter* parent = ivector[current_index];
    if((current_index * 2) < max-1){ //guarantees first child
        Voter* child1 = ivector[current_index*2 + 1];

        if((current_index * 2) < max){ //second child exists
            Voter* child2 = ivector[current_index*2 + 2];
            if(parent->impactCompare(*child1)){
                if(parent->impactCompare(*child2)){
                    //if child 1 < child 2
                    if(!(child2->impactCompare(*child1))){
                        swap_with = 2;
                    } else {
                        swap_with = 1;
                    }
                    //compare?
                } else {
                    swap_with = 1;
                }
            } else if (parent->impactCompare(*child2)){
                swap_with = 2;
            }
        } else {
            if(parent->impactCompare(*child1)){
                swap_with = 1;
            }
        }
    }

    if(swap_with>0){
        Voter* curr;
        if(swap_with == 1){
            curr = ivector[current_index*2 + 1];
        } else {
            curr = ivector[current_index*2 + 2];
        }
        parent->set_position(curr->get_position());
        curr->set_position(current_index);
        //change in vector
        ivector[curr->get_position()] = curr;
        ivector[parent->get_position()] = parent;
        return false;
    }
    return true;
}

void RegisterVoter::percolate_down(Voter* curr, int max){
    bool valid = false;
    int current_pos = curr->get_position();

    while(!valid){
        valid = swap_down(current_pos, max);
        current_pos = curr->get_position();
    }
}

void RegisterVoter::percolate_up(Voter* curr){
    bool valid = false;
    int current_pos = curr->get_position();

    while(!valid){
        valid = swap_up(current_pos);
        current_pos = curr->get_position();
    }
}
