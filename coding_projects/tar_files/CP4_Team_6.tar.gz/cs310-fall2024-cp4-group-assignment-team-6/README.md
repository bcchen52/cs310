# cs310-fall2024-cp4-group-assignment

Full Names: David Ramirez, Daniel(Donghwan) Kim, Brian Chen

GitHub IDs: statix.1 , easternblaze, bcchen52

Binghamton CS userids: dramirez2, dkim45, bchen17

Discord names: David Ramirez , Dong-Hwan Kim, run3father

Please type or copy the CS 310 honesty statement here:
We have worked on this project individually, and have not given or received too much help. In particular, We have not gained access to any other students' repositories, files, or code, nor have We given any other students access to mine. We have not used generative AI, including but not limited to chatGPT, unless explicitly authorized for this assignment. We understand that my code will be run through a very effective similarity checker, and that academic honesty violations are taken seriously.

With respect to the honesty statement, if you have any doubts whatsoever about whether you have completed the assignment appropriately, please describe briefly here:
