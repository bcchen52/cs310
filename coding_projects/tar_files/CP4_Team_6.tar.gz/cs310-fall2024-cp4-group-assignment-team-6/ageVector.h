#ifndef AGEVECTOR_H
#define AGEVECTOR_H

#include "Voter.h"
#include <vector>
#include <iostream>
using namespace std;

class ageVector {
private:
    vector<Voter*> ageIndex; // Array of linked list heads for each age 18-118

    // Helper function for printing voters of the same age.
    void printLL(Voter* head) const;

public:
    ageVector();
    ~ageVector();
    bool insertV(Voter* newVoter);
    bool ageComp(const Voter& voter) const;
    void makeLL(int age, Voter* newVoter);
    void removeV(Voter* voter);
    void showImpact() const;
};

#endif 