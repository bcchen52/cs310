#ifndef BST_H
#define BST_H

#include "Voter.h"
#include <string>
using namespace std;


class BST {
public:
   
    BST();
    ~BST();

    bool addVoter(Voter* voter);
    Voter* search(const string& lastName, const string& firstName);
    void deleteNode(const string& lastName, const string& firstName);

    Voter* deleteNodeRec(const string& lastName, const string& firstName);

private:
    Voter* root;
    void deleteTree(Voter* node);
    Voter* removeMin(Voter* node);
};

#endif
