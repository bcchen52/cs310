#include "BST.h"
#include <iostream>

// constructor
BST::BST(){
    root = nullptr; 
}

// destructor
BST::~BST(){
    deleteTree(root); 
}



// adds voter to the BST and returns the voter
bool BST::addVoter(Voter* voter){
 
    // if no root
    if (root == nullptr) {
        root = voter;
        return true;
    }

    Voter* current = root;
    Voter* parent = nullptr;

    // traverse the tree to add voter
    while (current != nullptr) {
        parent = current;
        if(*voter == *current){
            return false;
        } else if (*voter < *current){
            current = current->left; // left
        } else {
            current = current->right; // right
        }
    }

    // inserts node
    if (*voter<*parent) {
        parent->left = voter;
    } else {
        parent->right = voter;
    }

    return true;
}


//search for voter based on first and last name
Voter* BST::search(const string& lastName, const string& firstName) {

    Voter* current = root;
    Voter* voter = new Voter(firstName, lastName, 0);

    while (current != nullptr) {
        if (*voter==*current) {
            delete voter;
            return current;
             //left
        } else if (*voter<*current) {
            current = current->left; //right
        } else {
            current = current->right;
        }
    }

    delete voter;
    return nullptr;  
}


// deletes voter by name recursively
void BST::deleteNode(const string& lastName, const string& firstName){
    deleteNodeRec(lastName, firstName); 
}

// recusively delete all nodes in the tree
void BST::deleteTree(Voter* node){

    if (node) {
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }
}


// delete node, return deleted node 
Voter* BST::deleteNodeRec(const string& lastName, const string& firstName) {
    bool found = false;
    Voter* curr = root;
    Voter* voter = new Voter(firstName, lastName, 0);
    Voter* parent = nullptr;

    while(!found){
        if(*voter == *curr){
            found = true;
        } else if (*voter < *curr){
            parent = curr;
            curr = curr->left;
            if(curr == nullptr){
                found = true;
            }
        } else {
            parent = curr;
            curr = curr->right;
            if(curr == nullptr){
                found = true;
            }
        }
    }

    //if curr is nullptr, not found

    if(curr != nullptr) {
        if(curr->right != nullptr){
            if(curr->left != nullptr){
                //2 children
                Voter* temp = removeMin(curr->right);

                if(parent != nullptr){
                    if(*curr<*parent){
                        parent->left = temp;
                    } else {
                        parent->right = temp;
                    }
                } else {
                    root = temp;
                }

                if(temp != curr->right){
                    temp->right = curr->right;
                } else {
                    temp->right = curr->right;
                }

                temp->left = curr->left;

            }
        //1 child
            if(parent != nullptr){
                if(*curr<*parent){
                    parent->left = curr->right;
                } else {
                    parent->right = curr->right;
                }
            } else {
                root = curr->right;
            }
        } else if (curr->left != nullptr){
            //1 child
            if(parent != nullptr){
                if(*curr<*parent){
                    parent->left = curr->left;
                } else {
                    parent->right = curr->left;
                }
            } else {
                root = curr->left;
            }
        } else {
            //0 child
            if(parent != nullptr){
                if(*curr<*parent){
                    parent->left = nullptr;
                } else {
                    parent->right = nullptr;
                }
            } else {
                root = nullptr;
            }
        }
    } 

    delete voter;
    return curr;
}


//finds min node in subtree
Voter* BST::removeMin(Voter* node) {
    Voter* parent = nullptr;
    if (!node) {
        return nullptr;
    }

    while (node->left) {
        parent = node;
        node = node->left;
    }

    if(parent!=nullptr){
        parent->left = nullptr;
    }

    return node;
}

