#ifndef _H_RegisterVoter_
#define _H_RegisterVoter_

#include <iostream>
#include <stdlib.h>
#include <vector>
#include <cmath> 

#include "Voter.h"
#include "BST.h"
#include "ageVector.h"

using namespace std;

class RegisterVoter {
    private:
        vector<Voter*> ivector;
        ageVector* aVector;
        BST* bst;

        //declare BST and Vector types

    public:
        RegisterVoter();
        bool voter(string first, string last, int age); //return if sucessfully added
        void voted(string first, string last, int age);
        void reduce_likelihood(string first, string last, double change);
        void support(string first, string last, double change);
        void chauffeur();
        void show_impact();
        bool swap_down(int current_index, int max);
        bool swap_up(int current_index);
        void percolate_down(Voter* curr, int max);
        void percolate_up(Voter* curr);
};

#endif