#include "ageVector.h"
using namespace std;

ageVector::ageVector() {
    ageIndex.resize(101, nullptr); // Initialize vector with nullptr for ages 18-118
}

ageVector::~ageVector() {
    for (int i = 0; i < 101; ++i) {
        Voter* current = ageIndex[i];
        while (current != nullptr) {
            Voter* temp = current;
            current = current->next;
            delete temp;
        }
    }
}

bool ageVector::insertV(Voter* newVoter) {
    int age = newVoter->getAge();
    makeLL(age - 18, newVoter);
    return true;
}

bool ageVector::ageComp(const Voter& voter) const {
    int ageIdx = voter.getAge() - 18;
    Voter* current = ageIndex[ageIdx];
    while (current) {
        if (*current == voter) return true;
        current = current->next;
    }
    return false;
}

void ageVector::makeLL(int ageIdx, Voter* newVoter) {
    newVoter->next = ageIndex[ageIdx]; // Insert at the beginning
    ageIndex[ageIdx] = newVoter;
}

void ageVector::printLL(Voter* head) const {
    Voter* current = head;
    while (current != nullptr) {
        current->show_full();
        cout << endl;
        current = current->next;
    }
}

void ageVector::showImpact() const {
    for (int i = 0; i < 101; ++i) {
        if (ageIndex[i] != nullptr) {
            printLL(ageIndex[i]);
        }
    }
}

void ageVector::removeV(Voter* voter) {
    int ageIdx = voter->getAge() - 18;
    Voter* current = ageIndex[ageIdx];
    Voter* previous = nullptr;
    while (current != nullptr) {
        if (current == voter) {
            if (previous == nullptr) {
                // Special case: removing head of the linked list
                ageIndex[ageIdx] = current->next;
            } else {
                previous->next = current->next;
            }
            return;
        }
        previous = current;
        current = current->next;
    }
}
